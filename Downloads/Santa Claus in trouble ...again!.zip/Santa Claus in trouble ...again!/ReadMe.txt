============================================================

 SANTA CLAUS IN TROUBLE ...AGAIN! - Demo

============================================================

 Thank you for playing!

 Joymania & CDV Entertainment

============================================================
 SYSTEM REQUIREMENT
============================================================


-	Windows� 98/ME/2000/XP
-	Intel� or AMD� Processor with 450 MHz
-	DirectX� 8.1
-	3D Video Accelerator Card e.g. TNT2, ATI Radeon, GeForce Series
-	128 MB RAM
-	16 MB free disc space
-	Soundcard with DirectX� support


============================================================
 THE MENUS
============================================================

Start Game - Start a new game.
Highscores - View a list of the 10 best players along with their scores.
Options - Customize volume and controls and choose a language.
Quit - Exit the game and quit to the Windows desktop.



============================================================
 CONTROLS
============================================================

Keyboard controls:

-	Move the character with the cursor key or alternatively with
	the A, W, S and D keys.
-	Jump with Space or the E and J keys.

Mouse controls:

-	Move the character with the right mouse button or alternatively 
	with the cursor keys.
-	Jump with the left mouse button.

Joystick/Game pad controls:

-	Move the character with the primary stick.
-	Jump with the primary or secondary firing button.


============================================================
 TROUBLE SHOOTING
============================================================

 DIRECTX

       Please make sure that you have installed the latest direct-x version. 


 - Video cards

       Please make sure that you have installed the latest graphics driver.
       See below the internet addresses of the most popular video card manufacturers:
     
       3Dlabs - www.3dlabs.com/ 
       ATI - www.ati.com/de/index.html
       Canopus - www.canopusgmbh.de/Index_DE.asp/ 
       Gateway 2000 - www.gw2k.com/ 
       Guillemot/Hercules - www.guillemot.com/ 
       I/O Magic - www.iomagic.com/ 
       Jaton - www.jaton.com/ 
       Leadtek - www.leadtek.com/ 
       Matrox - www.matrox.com/ 
       NVIDIA - www.nvidia.com/ 
       S3 Incorporated - www.s3.com/ 
       SiS - www.sis.com.tw/ 
       VIA Technologies - www.viatech.com/



============================================================


(c) 2004 CDV Software Entertainment AG.
All rights reserved.
CDV, the CDV logo and SANTA CLAUS IN TROUBLE ...AGAIN!
are either registered trademarks or trademarks of CDV
Software Entertainment AG or Joymania
in the US and/or UK and/or other countries.



